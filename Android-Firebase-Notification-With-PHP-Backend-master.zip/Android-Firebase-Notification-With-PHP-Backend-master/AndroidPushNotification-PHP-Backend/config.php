<?php
 
// Firebase API Key
define('FIREBASE_API_KEY', 'PUT YOUR OWN FIREBASE SERVER KEY');

?>
